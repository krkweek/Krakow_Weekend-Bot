# Krakow Weekend Bot 🇵🇱

Телеграм-бот для группы Krakow Weekend:
- Верификация участников
- Удаление ссылок
- Создание мероприятий
- Пинг всех участников

## Установка
1. Установи зависимости: `pip install -r requirements.txt`
2. Запусти бота: `python bot.py`

## Хостинг
Подходит для Render, Railway, Heroku и VPS.
