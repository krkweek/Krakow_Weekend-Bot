from aiogram import Router, F
from aiogram.types import Message
from config import CHAT_ID

router = Router()

@router.message(F.chat.type == "private")
async def handle_verification(message: Message):
    await message.answer("Привет! Пожалуйста, укажи имя, возраст и немного о себе. После проверки тебя добавят в Krakow Weekend.
❗ В чате запрещена реклама и ссылки.")
