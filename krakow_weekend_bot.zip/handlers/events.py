from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command

router = Router()
events = {}

@router.message(Command("new_event"))
async def new_event(message: Message):
    await message.answer("Создание мероприятий пока в разработке. В следующих версиях будет поддержка кнопок и регистрации.")
