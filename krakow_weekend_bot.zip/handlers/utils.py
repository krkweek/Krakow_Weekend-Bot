from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command

router = Router()

@router.message(Command("ping_all"))
async def ping_all(message: Message):
    await message.answer("⛔ Временное ограничение Telegram API: массовое упоминание невозможно. Будет реализовано частично в будущих версиях.")
